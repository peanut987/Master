using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleAvoid : MonoBehaviour
{
    public TankSpawner tankSpawner;
    public Transform obstacleRoot;
    public TranningSetting trainingSetting;
    public int teamnum, enemynum;
    private RaycastHit hit;
    //private Vector3 MoveDir, MoveDir1, TeamMateDir, OtherEnemyDir = Vector3.zero;
    // Start is called before the first frame update
    void Start()
    {
        tankSpawner = FindObjectOfType<TankSpawner>();
        trainingSetting = FindObjectOfType<TranningSetting>();
        teamnum = trainingSetting.BlueTeam.nums;
        enemynum = trainingSetting.RedTeam.nums;
    }

    //ͨ������ÿ���ϰ����̹�˵ĺ���������з���������ٱ��Ϸ�Χ����������Ϊ�㣬����ԽС������Խ��
    public Vector3 CacPosition(ManControl man, Transform transform, Vector3 target)
    {
        Vector3 MoveDir = Vector3.zero, MoveDir1 = Vector3.zero, TeamMateDir = Vector3.zero, OtherEnemyDir = Vector3.zero;
        Vector3 EnemyDir = target - transform.position;
        //EnemyDir = new Vector3(EnemyDir.x, EnemyDir.y + 2, EnemyDir.z) ;
        //����Ѷ������ĺ���
        for (int i = 0; i < teamnum; i++)
        {
            float TeamMateDis = man.TeamMateDis1[i];
            float angle = man.baseFunction.DotCalculate(man.transform, tankSpawner.Biolist[i].transform)[1];
            float position_y = Mathf.Abs(transform.position.y - tankSpawner.Biolist[i].transform.position.y);
            if ((TeamMateDis < man.TeammateAvoidDis) && TeamMateDis != 10000.0f && angle < 70 && position_y < 3)
            {
                if (man.MinNum == -1 || man.baseFunction.CalculateDisX0Z(man.transform.position, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position) > man.BackDistance - 5)
                {
                    TeamMateDir = transform.position - tankSpawner.Biolist[i].transform.position;
                }
                else
                    TeamMateDir = Vector3.zero;
            }
            else
                TeamMateDir = Vector3.zero;
            MoveDir1 += TeamMateDir / (1 + TeamMateDis / 10);
        }

        //if (man.TankNum != 1 && (man.TankNum == 2 || man.TankNum == 3))
        //{
        //    //EnemyDir = Vector3.zero;
        //    if (man.TeamMateDis1[0] < 20)
        //    {
        //        TeamMateDir = transform.position - tankSpawner.Biolist[0].transform.position;
        //    }
        //    else TeamMateDir = tankSpawner.Biolist[0].transform.position - transform.position;
        //    MoveDir1 += TeamMateDir.normalized * Mathf.Abs(man.TeamMateDis1[0] - 20) 
        //        / (1 + Vector3.Distance(tankSpawner.Biolist[0].transform.position,transform.position) / 10);
        //}
        //	
        //}
        //      int Rmask = LayerMask.GetMask("GroundLayer");
        //      Vector3 Point_dir = transform.TransformDirection(Vector3.down);
        //      if (Physics.Raycast(transform.position, -transform.up, out hit, 10.0f, Rmask))
        //{

        //}
        //���������ֶ������ĺ���
        //for (int i = 0; i < enemynum; i++)
        //{
        //	float EnemyDis = (tankSpawner.BlueAgentsList[i].transform.position - transform.position).magnitude;
        //	if ((EnemyDis < man.EnemyAvoidDis) && (tankSpawner.BlueAgentsList[i].IsDea == false) && i != man.MinNum - 1)
        //		OtherEnemyDir = transform.position - tankSpawner.BlueAgentsList[i].transform.position;
        //	else
        //		OtherEnemyDir = Vector3.zero;
        //	MoveDir1 += OtherEnemyDir / (1 + EnemyDis / 10);
        //}
        //MoveDir = (MoveDir1 / 100 + EnemyDir.normalized / (1 + EnemyDis[man.MinNum - 1] * 50) + ObstacleVector(45.0f, 8)).normalized;

        //MoveDir = (MoveDir1 / 100 + EnemyDir / (10000 + man.EnemyDis[man.MinNum - 1]) + ObstacleVector(man, transform, 11.25f, 6)).normalized;
        MoveDir = (MoveDir1 / 100 + EnemyDir / (1000)).normalized;
        //MoveDir = new Vector3(MoveDir.x, MoveDir.y + 2, MoveDir.z);
        return MoveDir;
    }
}
