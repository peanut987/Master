using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using System;
using System.Linq;

public class FindEnemy : MonoBehaviour
{
    // Start is called before the first frame update
    public TankSpawner tankSpawner;
    public BaseFunction baseFunction;
    public ObstacleAvoid obstacleAvoid;
    public PathOptimize pathOptimize;
    public float BackDistance = 50;//后撤距离
    private RaycastHit hit;

    void Start()
    {
        tankSpawner = FindObjectOfType<TankSpawner>();
        baseFunction = FindObjectOfType<BaseFunction>();
        obstacleAvoid = FindObjectOfType<ObstacleAvoid>();
        pathOptimize = FindObjectOfType<PathOptimize>();
        BackDistance = 45;


    }

    //后撤距离设置函数，针对不同情况设置不同的后撤距离
    float KeepDis(ManControl man)
    {
        float dis = 24.0f;
        man.EnemyAttackNum = 0;
        if (man.EnemyAttackNum >= 2)
            dis = 24;
        if (man.Enemyinf[2] > 50 && man.EnemyDis[man.MinNum - 1] < 40)
            dis = 20;
        return dis;
    }

    //寻找并攻击敌军
    public void Scout(ManControl man, Transform transform)
    {
        if (man.TeamNum >= 20) FindTopPoints(man);//派出坦克占领高地
        float t = 0.01f;
        man.OpenFireDis = 80.0f;//设置开火范围
        man.BioTeanMateDir.Clear();
        man.BioAllTeammateDir.Clear();

        for (int i = 0; i < man.TeamNum; i++)
        {
            if (tankSpawner.Biolist[i].isActiveAndEnabled == true)
            {
                man.BioAllTeammateDir.TryAdd(man.TeamMateDis1[i], tankSpawner.Biolist[i]);
            }
        }

        if (man.MinNum == -1)
        {
            for (int i = 0; i < 20; i++)
            {
                if (tankSpawner.Biolist[i].MinNum != -1)
                {
                    man.BioTeanMateDir.TryAdd(man.TeamMateDis1[i], tankSpawner.Biolist[i]);
                }

            }
            //print(man.BioTeanMateDir.First().Value.MinNum);
            man.MinNum = man.BioTeanMateDir.First().Value.MinNum;
        }
        man.BioTeanMateDir.Clear();
        if (man.MinNum != -1)
        {
            //计算对手的方位
            float[] TempRot = baseFunction.DotCalculate(transform, tankSpawner.BlueAgentsList[man.MinNum - 1].transform);
            man.Enemyinf[0] = TempRot[0];
            man.Enemyinf[1] = TempRot[1]; //baseFunction.DotCalculate3(transform, tankSpawner.BlueAgentsList[man.MinNum - 1].transform); ;
            TempRot[1] = baseFunction.CrossCalculate1(transform, tankSpawner.BlueAgentsList[man.MinNum - 1].transform);
            man.Enemyinf[2] = TempRot[1];//右边为正左边为负值

            //拉扯进攻，即前后移动发炮，此时将man.RegularFlag标志位置1，即不执行移动动作
            //触发条件：对手炮筒对准自己&&对手距离小于40并大于后撤距离
            //正面主力进入拉扯模式
            //if (man.Enemyinf[1] < 5 && man.EnemyDis[man.MinNum - 1] < 50)
            //{
            //	man.OpenFireDis = BackDistance + 1;
            //	if (man.firetime <= man.cooldowntime / 2)
            //	{
            //		man.RegularFlag = 1;
            //		man.move(-man.MaxSpeed, 0);
            //	}
            //	else if (man.firetime > man.cooldowntime / 2 && man.firetime <= man.cooldowntime)
            //	{
            //		man.RegularFlag = 1;
            //		man.move(man.MaxSpeed, 0);
            //	}
            //	else
            //		man.RegularFlag = 0;
            //}
            //else
            //	man.RegularFlag = 0;

            //速度确定代码，当对手距离大于后撤距离则全速前进，小于后撤距离则以0.8倍最大速度后撤
            man.enemyDisXOZ = baseFunction.CalculateDisX0Z(man.transform.position, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position);
            if (man.enemyDisXOZ <= man.BackDistance && baseFunction.DotCalculate(man.transform, tankSpawner.BlueAgentsList[man.MinNum - 1].transform)[1] < 30)
                man.relativespeed = -1.0f;
            else
                man.relativespeed = 1.0f;
        }

        //计算旋转速度，当前旋转使用slerp
        //man.relativerotate = 5.0f;
        //if (man.Enemyinf[1] > 5.0f)
        //{
        //    if (man.Enemyinf[1] < 0)
        //        man.relativerotate = 5.0f;
        //    else
        //        man.relativerotate = -5.0f;
        //}
        //else if (man.Enemyinf[1] <= 5.0f)
        //{
        //    if (man.Enemyinf[1] < 0)
        //        man.relativerotate = 0.1f;
        //    else
        //        man.relativerotate = -0.1f; ;
        //}
        //else if (man.Enemyinf[1] <= 10.0f && man.Enemyinf[1] > 0.5f)
        //    man.relativerotate = man.MaxSpeed * (180.0f - man.Enemyinf[1]) / 10.0f;



        //确定对手方位
        Vector3 target = Vector3.zero;//target为运行方向
        if (man.TeamNum >= 20)
        {
            if (man.HillIndex != -1)
            {
                if (Vector3.Distance(man.transform.position, man.gameManage.topPoints[man.HillIndex].transform.position) < 8.0f)
                {
                    if (man.BioEnemydir.Count != 0 && man.teammatelive > 5)
                    {
                        man.speedControl = false;
                        man.lineRenderer.enabled = true;
                        target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                        man.move(1, 0);
                        //man.Muti_Ray_Cast(man.transform.position,man.BioEnemydir);
                    }
                    else
                    {
                        man.lineRenderer.enabled = false;
                        man.highFlag = 1;
                        man.speedControl = true;
                    }
                    //man.move(0.2f, 0);
                }
                else if (man.highFlag == 0)
                {
                    man.lineRenderer.enabled = false;
                    man.speedControl = true;
                    target = man.gameManage.topPoints[man.HillIndex].transform.position;
                }
                else
                {
                    man.highFlag = 1;
                    man.speedControl = true;
                    target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                    //if (man.BioEnemydir.Count == 0)
                    //{
                    //    man.highFlag = 1;
                    //    man.speedControl = true;
                    //    target = man.BioAllTeammateDir.First().Value.transform.position;
                    //}
                    //else
                    //{
                    //    man.highFlag = 1;
                    //    man.speedControl = true;
                    //    target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                    //}
                }

                if (man.BioEnemydir.Count != 0)
                {
                    if (Vector3.Distance(tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position,
                        man.gameManage.topPoints[man.HillIndex].transform.position) > 200.0f)
                    {
                        target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                    }
                }

            }
            else if (man.Enemy_len == 0)
            {
                for (int i = 0; i < indexFlag.Length; i++)
                {
                    float teamDis = Vector3.Distance(man.transform.position, tankSpawner.Biolist[indexFlag[i] - 1].transform.position);

                    man.BioTeanMateDir.TryAdd(teamDis, tankSpawner.Biolist[indexFlag[i] - 1]);
                }
                //print(man.BioTeanMateDir.Count);
                if (man.BioTeanMateDir.First().Value.speedControl == false)
                {
                    man.speedControl = false;
                    foreach (var Bio in man.BioTeanMateDir)
                    {
                        if (Bio.Value.Enemy_len != 0)
                        {
                            man.speedControl = true;
                            target = Bio.Value.transform.position;
                            break;
                        }
                    }
                    if (man.speedControl == false)
                    {
                        target = man.BioTeanMateDir.ElementAt(1).Value.transform.position;
                        man.speedControl = true;
                    }
                }
                else
                {
                    man.speedControl = true;
                    target = man.BioTeanMateDir.First().Value.transform.position;
                }

                //man.speedControl = true;
                //target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
            }
            else
                target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
        }
        else
            target = assign_target(man);

        int Rmask = LayerMask.GetMask("GroundLayer");
        man.target1 = target;//通过target1能够在inspector直观显示锁定对手的位置信息

        //这段代码为延时函数，防止动作跳变
        //man.timeBetween++;
        //if (5 == man.timeBetween)
        //{
        //    //if (Physics.Raycast(transform.position, -transform.up, out hit, 20.0f, Rmask))  //&& (baseFunction.angleOffset(angle.x) > -5 || baseFunction.angleOffset(angle.x) < -35))
        //    //{
        //    //	//Quaternion NextRot = Quaternion.LookRotation(Vector3.Cross(hit.normal, Vector3.Cross(transform.forward, hit.normal)), hit.normal);
        //    //	Quaternion targetRotation = Quaternion.FromToRotation(transform.up, hit.normal) * transform.rotation;
        //    //	transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, Time.deltaTime * 50f);
        //    //}
        //    man.offset = obstacleAvoid.CacPosition(man, transform, target);
        //    man.offset[1] = 0;
        //    man.timeBetween = 0;
        //}
        man.offset = obstacleAvoid.CacPosition(man, transform, target);//通过避障函数求出运行方向
        man.offset[1] = 0;//令y方向为0
        if (man.HillIndex == -1) man.Ray_Cast(man.transform.position, man.transform.position + man.offset);//通过射线将方向显示出来
        man.ControlFlag = true;

        //t值可以保证坦克在旋转过程中比较平稳
        t = 0.0f;
        t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));


        if (man.RegularFlag == 0)
        {
            //坦克动作执行代码，转向由Slerp函数执行，前进由man.move函数执行
            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
            man.transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, t);
            if (man.speedControl)
            {
                man.move(man.relativespeed * man.MaxSpeed, 0);
            }
        }
        //RealShoot(man, man.transform.position, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position);
        attack_enemy(man);


    }

    Vector3 move_target1(ManControl man, int leaderNum, float angle, float distance)
    {
        Vector3 target = Vector3.zero;
        if (man.EnemyDis[man.MinNum - 1] > man.BackDistance + 10)
            target = baseFunction.Set_point(tankSpawner.Biolist[leaderNum - 1].transform, angle, distance);
        else
            target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
        return target;
    }

    Vector3 assign_target(ManControl man)
    {
        Vector3 target = Vector3.zero;
        switch (man.TankNum)
        {
            case 1:
                target = move_target1(man, 2, -(man.TankNum - 2) * 90, 20);
                break;
            case 2:
                target = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                break;
            case 3:
                target = move_target1(man, 2, -(man.TankNum - 2) * 90, 20);
                break;
                //default:


        }
        return target;
    }

    public float[] bufferDis = new float[20];
    public float[] bufferDis1 = new float[20];
    public int[] indexFlag = new int[7];
    public int[] indexFlagCount = new int[7];
    //SortedDictionary<float, ManControl> BioTopDir = new();
    public int FindTopPoints(ManControl man)
    {
        //BioTopDir.Clear();
        //float[] bufferDis1 = new float[20];
        int num = 20;
        int minIndex = 0;
        for (int i = 0; i < 7; i++)
        {
            if (indexFlag[i] == 0 || tankSpawner.Biolist[indexFlag[i] - 1].isActiveAndEnabled == false)
            {
                for (int j = 0; j < num; j++)
                {
                    bufferDis[j] = tankSpawner.Biolist[j].HillIndex != -1 ? 1000 :
                        Vector3.Distance(tankSpawner.Biolist[j].transform.position, man.gameManage.topPoints[i].position);
                    bufferDis1[j] = bufferDis[j];
                }
                Array.Sort(bufferDis1);
                for (int j = 0; j < num; j++)
                {
                    if (bufferDis[j] == bufferDis1[0] && tankSpawner.Biolist[j].HillIndex == -1)
                    {
                        tankSpawner.Biolist[j].topFlag = true;
                        tankSpawner.Biolist[j].HillIndex = i;
                        indexFlag[i] = j + 1;
                        indexFlagCount[i]++;
                        break;

                    }
                }
            }


        }
        return minIndex;

    }

    private float PID_Speed(float P_error, float I_error, float D_error, float speed, float P, float I, float D, float I_error_limit)
    {
        if (I_error > I_error_limit)
        {
            I_error = I_error_limit;
        }
        if (I_error < -I_error_limit)
        {
            I_error = -I_error_limit;
        }
        float error = P * P_error + I * I_error + D * D_error;
        speed += error;
        if (speed > 20)
        {
            speed = 20;
        }
        if (speed < -20)
        {
            speed = -20;
        }
        return speed;

    }
    private float angle_change(float angle, float min)//将弧度角等效为min-------min+2π的范围内
    {
        while (angle > min + 2 * Mathf.PI || angle < min)
        {
            if (angle > min + 2 * Mathf.PI)
            {
                angle -= Mathf.PI;
            }
            else
            {
                angle += Mathf.PI;
            }
        }
        return angle;

    }
    public List<int> Group_1 = new List<int>();//各组坦克 存的是敌方坦克编号
    public List<int> Group_2 = new List<int>();

    public bool execute = false;
    public bool assign_done = false;//是否已经分配完成 //以下别删
    public int attack_team_beside_num = 0;//攻方侧边个数
    public int attack_team_middle_num = 0;//攻方中间个数
    public int block_team_beside_num = 0;//阻方侧边个数
    public int block_team_middle_num = 0;//阻方中间个数
    public List<int> attack_team_beside_Group = new List<int>();//各组坦克 存的是敌方坦克编号 //这四个不能直接拖到函数外public显示 需复制
    public List<int> attack_team_middle_Group = new List<int>();
    public List<int> block_team_beside_Group = new List<int>();
    public List<int> block_team_middle_Group = new List<int>();
    public int attack_team_beside_leader_num = 0;//领队坦克编号
    public int attack_team_middle_leader_num = 0;
    public int block_team_beside_leader_num = 0;
    public int block_team_middle_leader_num = 0;
    public Vector3 Attack_beside_Point = Vector3.zero;
    public Vector3 Attack_middle_Point = Vector3.zero;
    public Vector3 Block_beside_Point = Vector3.zero;
    public Vector3 Block_middle_Point = Vector3.zero;
    public float[] P_error = new float[20];
    public float[] I_error = new float[20];
    public float[] D_error = new float[20];
    public float[] speed = new float[20];
    public float[] temp_angle = new float[20];
    public Vector3[] move_target = new Vector3[20];
    public bool attack_beside_arrive = false;
    public bool attack_middle_arrive = false;
    public bool block_middle_arrive = false;
    public bool block_beside_arrive = false;


    public void Tactic_attack_less_block_more(ManControl man)
    {
        //在将变量拖至函数外public显示时 十分建议在函数最底下复制到外面

        //总控
        bool allview = true;//是否有全局视野

        //分类用
        const int BlueAgentsList_num = 20;//敌方总坦克数 包括死的 20 //视野全开用
        int BlueAgentsList_alive_num = man.enemylive;//敌方活着的坦克数 
        int BlueAgentsList_seen_num = man.BioEnemydir.Count;//敌方可视坦克数
        Vector3 Average1 = Vector3.zero;//已知的第一组的中心点
        Average1 = tankSpawner.BlueAgentsList[0].transform.position;//初始化1次
        Vector3 Average2 = Vector3.zero;//已知的第二组的中心点
        Average2 = tankSpawner.BlueAgentsList[1].transform.position;
        List<int> Group1 = new List<int>();//各组坦克 存的是敌方坦克编号 //这俩不能直接拖到函数外public显示 需复制
        List<int> Group2 = new List<int>();
        int looptimes = 20;//循环时间
        Vector3 New_Average1 = Vector3.zero;//新中心点
        Vector3 New_Average2 = Vector3.zero;
        int Group1_num = 0;//各组坦克数量 //这俩不能直接拖到函数外public显示
        int Group2_num = 0;

        //计算分类后结果用 （判断）
        float Group_avg_dist1 = 0;//各组距离误差  //这俩不能直接拖到函数外public显示 需复制
        float Group_avg_dist2 = 0;
        float group1_max_dist = 0;//各组离中心点最大距离
        float group2_max_dist = 0;
        float dist_Average1_to_Average2 = 0; //两组中心点间的距离
        float Average1_angle = 0;//从组1中心点到组2中心点的角度 x-z二维平面 x-y替换成x-z
        float Average2_angle = 0;//同上但是相反
        float dist_Average1_to_central = 0;//组1中心点到交界带的距离
        float dist_Average2_to_central = 0;//组2中心点到交界带的距离
        float central_width = 0;//交界带的宽度
        Vector3 Central_SpecialPoint1 = Vector3.zero;//交界带特征点
        Vector3 Central_SpecialPoint2 = Vector3.zero;
        Vector3 Central_Point = Vector3.zero;
        int team_alive_num = man.teammatelive;
        bool Execute = true;//不能直接拖到函数外public显示 需复制 
        bool attack_group1 = false;//这个是true说明攻组1阻组2 反之
        float attack_max_dist_enemy = 0;
        float block_max_dist_enemy = 0;


        //我方分配队伍用
        const int team_num = 20;//我方坦克数 

        //PID用
        //float[] P_error = new float[team_num];
        //float[] I_error = new float[team_num];
        //float[] D_error = new float[team_num];
        //float[] speed = new float[team_num];
        //遍历敌方坦克 顺便再次初始化中心点 
        if (allview)//视野全开用
        {
            for (int i = 0; i < BlueAgentsList_num; i++)
            {
                if (tankSpawner.BlueAgentsList[i].isActiveAndEnabled == true)//
                {
                    Vector3 temp = Vector3.zero;
                    temp = tankSpawner.BlueAgentsList[i].transform.position;
                    float distance1 = (temp.x - Average1.x) * (temp.x - Average1.x) + (temp.z - Average1.z) * (temp.z - Average1.z);//计算距离
                    float distance2 = (temp.x - Average2.x) * (temp.x - Average2.x) + (temp.z - Average2.z) * (temp.z - Average2.z);
                    if (distance1 <= distance2)
                    {
                        Group1.Add(i);
                        New_Average1.x += temp.x;
                        New_Average1.z += temp.z;
                        Group1_num++;
                    }
                    else
                    {
                        Group2.Add(i);
                        New_Average2.x += temp.x;
                        New_Average2.z += temp.z;
                        Group2_num++;
                    }
                }
                else
                {
                    continue;
                }

            }
        }
        else
        {
            foreach (TankControl element in man.BioEnemydir.Values)//遍历敌方坦克 顺便再次初始化中心点 
            {
                if (tankSpawner.BlueAgentsList[element.TankNum].isActiveAndEnabled == true)//
                {
                    Vector3 temp = Vector3.zero;
                    temp = tankSpawner.BlueAgentsList[element.TankNum].transform.position;
                    float distance1 = (temp.x - Average1.x) * (temp.x - Average1.x) + (temp.z - Average1.z) * (temp.z - Average1.z);//计算距离
                    float distance2 = (temp.x - Average2.x) * (temp.x - Average2.x) + (temp.z - Average2.z) * (temp.z - Average2.z);
                    if (distance1 <= distance2)
                    {
                        Group1.Add(element.TankNum);
                        New_Average1.x += temp.x;
                        New_Average1.z += temp.z;
                        Group1_num++;

                    }
                    else
                    {
                        Group2.Add(element.TankNum);
                        New_Average2.x += temp.x;
                        New_Average2.z += temp.z;
                        Group2_num++;
                    }
                }
                else
                {
                    continue;
                }

            }
        }
        //计算新中心点
        New_Average1 /= Group1_num;
        New_Average2 /= Group2_num;
        Average1 = New_Average1;
        New_Average1 = Vector3.zero;
        Average2 = New_Average2;
        New_Average2 = Vector3.zero;
        if (BlueAgentsList_alive_num >= 2)//活着的敌方数量
        {
            for (int i = 0; i < looptimes; i++)//开始循环
            {
                //开始二分类
                List<int> NewGroup1 = new List<int>();
                List<int> NewGroup2 = new List<int>();
                foreach (int element in Group1)//遍历组1
                {
                    Vector3 temp = Vector3.zero;
                    temp = tankSpawner.BlueAgentsList[element].transform.position;
                    float distance1 = Mathf.Sqrt((temp.x - Average1.x) * (temp.x - Average1.x) + (temp.z - Average1.z) * (temp.z - Average1.z));
                    float distance2 = Mathf.Sqrt((temp.x - Average2.x) * (temp.x - Average2.x) + (temp.z - Average2.z) * (temp.z - Average2.z));
                    if (distance1 <= distance2)
                    {
                        New_Average1.x += temp.x;
                        New_Average1.z += temp.z;
                        NewGroup1.Add(element);

                    }
                    else
                    {
                        Group1_num--;
                        Group2_num++;
                        NewGroup2.Add(element);
                        New_Average2.x += temp.x;
                        New_Average2.z += temp.z;

                    }
                }

                foreach (int element in Group2)//遍历组2
                {
                    Vector3 temp = Vector3.zero;
                    temp = tankSpawner.BlueAgentsList[element].transform.position;
                    float distance1 = Mathf.Sqrt((temp.x - Average1.x) * (temp.x - Average1.x) + (temp.z - Average1.z) * (temp.z - Average1.z));
                    float distance2 = Mathf.Sqrt((temp.x - Average2.x) * (temp.x - Average2.x) + (temp.z - Average2.z) * (temp.z - Average2.z));
                    if (distance1 <= distance2)
                    {
                        New_Average1.x += temp.x;
                        New_Average1.z += temp.z;
                        Group1_num++;
                        Group2_num--;
                        NewGroup1.Add(element);

                    }
                    else
                    {
                        New_Average2.x += temp.x;
                        New_Average2.z += temp.z;
                        NewGroup2.Add(element);

                    }

                }

                New_Average1 = New_Average1 / Group1_num;
                New_Average2 = New_Average2 / Group2_num;
                Group1 = NewGroup1;
                Group2 = NewGroup2;
                if (Average1 == New_Average1 && Average2 == New_Average2)//若上一次和这一次的中心点一样 就break
                {
                    break;
                }
                Average1 = New_Average1;
                New_Average1 = Vector3.zero;
                Average2 = New_Average2;
                New_Average2 = Vector3.zero;

            }
            ///////////////////////////K-MEANS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //计算分类后相关数据
            Average1_angle = Mathf.Atan2(Average2.z - Average1.z, Average2.x - Average1.x);
            Average2_angle = Mathf.Atan2(Average1.z - Average2.z, Average1.x - Average2.x);


            foreach (int element in Group1)//遍历组1
            {
                Vector3 temp = Vector3.zero;
                temp = tankSpawner.BlueAgentsList[element].transform.position;
                float distance1 = Mathf.Sqrt((temp.x - Average1.x) * (temp.x - Average1.x) + (temp.z - Average1.z) * (temp.z - Average1.z));
                float temp_angle = Mathf.Atan2(temp.z - Average1.z, temp.x - Average1.x);
                Group_avg_dist1 += distance1;
                if (distance1 > group1_max_dist)
                {
                    group1_max_dist = distance1;
                }
                if (temp_angle - Average1_angle > -Mathf.PI / 4 && temp_angle - Average1_angle < Mathf.PI / 4)
                {
                    float temp_central_dist = distance1 * Mathf.Cos(temp_angle - Average1_angle);
                    if (temp_central_dist > dist_Average1_to_central)
                    {
                        dist_Average1_to_central = temp_central_dist;
                    }
                }
            }

            foreach (int element in Group2)//遍历组2
            {
                Vector3 temp = Vector3.zero;
                temp = tankSpawner.BlueAgentsList[element].transform.position;
                float distance2 = Mathf.Sqrt((temp.x - Average2.x) * (temp.x - Average2.x) + (temp.z - Average2.z) * (temp.z - Average2.z));
                float temp_angle = Mathf.Atan2(temp.z - Average2.z, temp.x - Average2.x);
                Group_avg_dist2 += distance2;
                if (distance2 > group2_max_dist)
                {
                    group2_max_dist = distance2;
                }
                if (temp_angle - Average2_angle > -Mathf.PI / 4 && temp_angle - Average2_angle < Mathf.PI / 4)
                {
                    float temp_central_dist = distance2 * Mathf.Cos(temp_angle - Average2_angle);
                    if (temp_central_dist > dist_Average2_to_central)
                    {
                        dist_Average2_to_central = temp_central_dist;
                    }
                }
            }
            Group_avg_dist1 /= Group1_num;
            Group_avg_dist2 /= Group2_num;
            dist_Average1_to_Average2 = Mathf.Sqrt((Average1.x - Average2.x) * (Average1.x - Average2.x) + (Average1.z - Average2.z) * (Average1.z - Average2.z));
            central_width = dist_Average1_to_Average2 - dist_Average1_to_central - dist_Average2_to_central;
            if (central_width > 20 && Math.Abs(Group2_num - Group1_num) > 2 && Group1_num + Group2_num >= 15 && Group1_num != 0 && Group2_num != 0)//判断是否执行这个策略 //敌方数量与地理位置关系
            {
                if (team_alive_num - BlueAgentsList_alive_num > -1 && team_alive_num > 7)//敌我力量差与我方存活数
                {


                }
                if (!allview)//无全局视野用
                {
                    if ((float)BlueAgentsList_seen_num / BlueAgentsList_alive_num > 0.6f)//已知位置比
                    {
                        Execute = false;
                    }
                }
            }

            //执行
            if (Execute)
            {
                Central_SpecialPoint1.x = ((dist_Average1_to_central + central_width / 3) * Mathf.Cos(Average1_angle)) + Average1.x;
                Central_SpecialPoint1.z = ((dist_Average1_to_central + central_width / 3) * Mathf.Sin(Average1_angle)) + Average1.z;
                Central_SpecialPoint2.x = ((dist_Average2_to_central + central_width / 3) * Mathf.Cos(Average2_angle)) + Average2.x;
                Central_SpecialPoint2.z = ((dist_Average2_to_central + central_width / 3) * Mathf.Sin(Average2_angle)) + Average2.z;
                Central_Point = (Central_SpecialPoint1 + Central_SpecialPoint2) / 2;
                if (Group2_num > Group1_num)//确定攻哪一组
                {
                    attack_group1 = true;
                    Attack_beside_Point = Average1;
                    Attack_middle_Point = Central_SpecialPoint1;
                    Block_beside_Point = Average2;
                    Block_middle_Point = Central_SpecialPoint2;
                    attack_max_dist_enemy = group1_max_dist;
                    block_max_dist_enemy = group2_max_dist;
                }
                else
                {
                    attack_group1 = false;
                    Attack_beside_Point = Average2;
                    Attack_middle_Point = Central_SpecialPoint2;
                    Block_beside_Point = Average1;
                    Block_middle_Point = Central_SpecialPoint1;
                    attack_max_dist_enemy = group2_max_dist;
                    block_max_dist_enemy = group1_max_dist;
                }
                //分配我方坦克
                if (!assign_done)
                {
                    attack_team_middle_num = team_alive_num / 4;
                    block_team_middle_num = team_alive_num / 4;
                    attack_team_beside_num = ((team_alive_num - attack_team_middle_num - block_team_middle_num) / 2) + 2;
                    block_team_beside_num = team_alive_num - attack_team_beside_num - attack_team_middle_num - block_team_middle_num;
                    SortedDictionary<float, int> team_temp1 = new();//分配用 //int是编号
                    SortedDictionary<float, int> team_temp2 = new();
                    SortedDictionary<float, int> team_temp3 = new();
                    float k1 = (Attack_beside_Point.z - Block_beside_Point.z) / (Attack_beside_Point.x - Block_beside_Point.x);
                    float b1 = Attack_beside_Point.z - Attack_beside_Point.x * k1;
                    Vector3 standard = Vector3.zero;//确定方向标准用的向量
                    standard.x = Block_beside_Point.x - Attack_beside_Point.x;
                    for (int i = 0; i < team_num; i++)//初始化
                    {
                        if (tankSpawner.Biolist[i].isActiveAndEnabled == true)
                        {
                            Vector3 temp = Vector3.zero;
                            temp = tankSpawner.Biolist[i].transform.position;
                            float k2 = -1 / k1;
                            float b2 = temp.z - temp.x * k2;
                            Vector3 temp_cross = Vector3.zero;
                            temp_cross.x = (b2 - b1) / (k1 - k2);
                            temp_cross.z = k1 * temp_cross.x + b1;
                            float temp_dist = temp_cross.x - Attack_beside_Point.x;
                            if ((temp_dist / standard.x) < 0)
                            {
                                temp_dist = -Mathf.Abs(temp_dist);
                            }
                            else
                            {
                                temp_dist = Mathf.Abs(temp_dist);
                            }
                            team_temp1.Add(temp_dist, i);
                        }
                    }
                    int j = 1;
                    foreach (KeyValuePair<float, int> element in team_temp1)//分配
                    {
                        if (j <= attack_team_beside_num)
                        {
                            if (j == (int)1 + attack_team_beside_num / 2)
                            {
                                attack_team_beside_leader_num = element.Value;
                            }
                            attack_team_beside_Group.Add(element.Value);
                        }
                        else if (j <= attack_team_beside_num + attack_team_middle_num)
                        {
                            Vector3 temp = Vector3.zero;
                            temp = tankSpawner.Biolist[element.Value].transform.position;
                            float distance = Mathf.Sqrt((temp.x - Attack_middle_Point.x) * (temp.x - Attack_middle_Point.x) + (temp.z - Attack_middle_Point.z) * (temp.z - Attack_middle_Point.z));
                            team_temp2.Add(distance, element.Value);
                        }
                        else if (j <= attack_team_beside_num + attack_team_middle_num + block_team_middle_num)
                        {
                            Vector3 temp = Vector3.zero;
                            temp = tankSpawner.Biolist[element.Value].transform.position;
                            float distance = Mathf.Sqrt((temp.x - Block_middle_Point.x) * (temp.x - Block_middle_Point.x) + (temp.z - Block_middle_Point.z) * (temp.z - Block_middle_Point.z));
                            team_temp3.Add(distance, element.Value);
                        }
                        else
                        {
                            block_team_beside_Group.Add(element.Value);
                            if (j == (int)1 + attack_team_beside_num + attack_team_middle_num + block_team_middle_num + block_team_beside_num / 2)
                            {
                                block_team_beside_leader_num = element.Value;
                            }
                        }
                        j++;
                    }
                    j = 0;
                    foreach (KeyValuePair<float, int> element in team_temp2)//分配中间部分
                    {
                        if (j == 0)
                        {
                            attack_team_middle_leader_num = element.Value;
                        }
                        attack_team_middle_Group.Add(element.Value);
                        j++;
                    }
                    j = 0;
                    foreach (KeyValuePair<float, int> element in team_temp3)
                    {
                        if (j == 0)
                        {
                            block_team_middle_leader_num = element.Value;
                        }
                        block_team_middle_Group.Add(element.Value);
                        j++;
                    }
                    assign_done = true;
                }


                //move
                int leader_position_in_list = 0;
                //////////攻侧
                if (!attack_beside_arrive)
                {
                    for (int i = 0; i < attack_team_beside_Group.Count; i++)//剔除死亡
                    {
                        if (tankSpawner.Biolist[attack_team_beside_Group[i]].isActiveAndEnabled == false)
                        {
                            attack_team_beside_Group.RemoveAt(i);
                        }
                    }
                    for (int i = 0; i < attack_team_beside_Group.Count; i++)//确定领导者存活及List位置
                    {
                        if (attack_team_beside_Group[i] == attack_team_beside_leader_num)
                        {
                            leader_position_in_list = i;
                            break;
                        }
                        else if (i == attack_team_beside_Group.Count - 1)
                        {
                            leader_position_in_list = attack_team_beside_Group.Count / 2;
                            attack_team_beside_leader_num = attack_team_beside_Group[leader_position_in_list];
                        }
                    }
                    for (int i = 0; i < attack_team_beside_Group.Count; i++)
                    {
                        if (man.TankNum == attack_team_beside_Group[i] + 1)
                        {
                            float angle1 = Mathf.Atan2(tankSpawner.Biolist[attack_team_beside_leader_num].transform.forward.z, tankSpawner.Biolist[attack_team_beside_leader_num].transform.forward.x);
                            float angle2 = angle1 - Mathf.PI / 2;
                            float interval = 2 * attack_max_dist_enemy / (attack_team_beside_Group.Count - 1);
                            Vector3 temp1 = Vector3.zero;
                            Vector3 temp2 = Vector3.zero;
                            temp1.x = interval * Mathf.Cos(angle2);
                            temp1.z = interval * Mathf.Sin(angle2);
                            temp2.x = interval * Mathf.Cos(angle1);
                            temp2.z = interval * Mathf.Sin(angle1);

                            if (i == leader_position_in_list)
                            {
                                move_target[attack_team_beside_Group[i]].x = tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.x;
                                move_target[attack_team_beside_Group[i]].z = tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.z;
                                man.offset[0] = Attack_beside_Point.x - tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.x;
                                man.offset[2] = Attack_beside_Point.z - tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                if (Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]) < attack_max_dist_enemy)
                                {
                                    attack_beside_arrive = true;
                                }
                            }
                            else
                            {
                                move_target[attack_team_beside_Group[i]].x = (leader_position_in_list - i) * temp1.x +
                                    //Mathf.Abs((leader_position_in_list - i)) * temp2.x + 
                                    tankSpawner.Biolist[attack_team_beside_leader_num].transform.position.x;
                                move_target[attack_team_beside_Group[i]].z = (leader_position_in_list - i) * temp1.z +
                                    //Mathf.Abs((leader_position_in_list - i)) * temp2.z + 
                                    tankSpawner.Biolist[attack_team_beside_leader_num].transform.position.z;
                                man.offset[0] = move_target[attack_team_beside_Group[i]].x - tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.x;
                                man.offset[2] = move_target[attack_team_beside_Group[i]].z - tankSpawner.Biolist[attack_team_beside_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                float dist_err = Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]);
                                Vector3 temp = new Vector3(man.transform.forward.x, 0, man.transform.forward.z);
                                temp_angle[attack_team_beside_Group[i]] = Vector3.Angle(temp, man.offset);
                                if (temp_angle[attack_team_beside_Group[i]] > 90)
                                {
                                    //man.offset[0] = -man.offset[0];
                                    //man.offset[2] = -man.offset[2];
                                    dist_err = -dist_err;
                                }
                                float speed_err = speed[attack_team_beside_leader_num] - speed[attack_team_beside_Group[i]];
                                float rate = 0.72f;
                                float temp_err = rate * dist_err + (1 - rate) * speed_err;
                                D_error[attack_team_beside_Group[i]] = temp_err - P_error[attack_team_beside_Group[i]];
                                P_error[attack_team_beside_Group[i]] = temp_err;
                                I_error[attack_team_beside_Group[i]] += temp_err;

                            }
                            float t = 0.0f;
                            t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));
                            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
                            man.transform.rotation = Quaternion.Lerp(man.transform.rotation, targetRotation, t);
                            float temp_speed = 0;
                            if (i == leader_position_in_list)
                            {
                                temp_speed = 15;
                            }
                            else
                            {
                                temp_speed = PID_Speed(P_error[attack_team_beside_Group[i]], I_error[attack_team_beside_Group[i]], D_error[attack_team_beside_Group[i]], speed[attack_team_beside_Group[i]], 0.4f, 0f, 0.4f, 100f);
                                speed[attack_team_beside_Group[i]] = temp_speed;
                            }
                            man.move(temp_speed, 0);
                        }

                    }
                }
                else
                {
                    for (int i = 0; i < attack_team_beside_Group.Count; i++)
                    {
                        if (tankSpawner.Biolist[attack_team_beside_Group[i]].isActiveAndEnabled == true && man.TankNum == attack_team_beside_Group[i] + 1)
                        {
                            Scout(man, man.transform);
                        }
                    }
                }
                ///////阻侧
                if (!block_beside_arrive)
                {
                    for (int i = 0; i < block_team_beside_Group.Count; i++)//剔除死亡
                    {
                        if (tankSpawner.Biolist[block_team_beside_Group[i]].isActiveAndEnabled == false)
                        {
                            block_team_beside_Group.RemoveAt(i);
                        }
                    }
                    for (int i = 0; i < block_team_beside_Group.Count; i++)//确定领导者存活及List位置
                    {
                        if (block_team_beside_Group[i] == block_team_beside_leader_num)
                        {
                            leader_position_in_list = i;
                            break;
                        }
                        else if (i == block_team_beside_Group.Count - 1)
                        {
                            leader_position_in_list = block_team_beside_Group.Count / 2;
                            block_team_beside_leader_num = block_team_beside_Group[leader_position_in_list];
                        }
                    }
                    for (int i = 0; i < block_team_beside_Group.Count; i++)
                    {
                        if (man.TankNum == block_team_beside_Group[i] + 1)
                        {
                            float angle1 = Mathf.Atan2(tankSpawner.Biolist[block_team_beside_leader_num].transform.forward.z, tankSpawner.Biolist[block_team_beside_leader_num].transform.forward.x);
                            float angle2 = angle1 - Mathf.PI / 2;
                            float interval = 2 * block_max_dist_enemy / (block_team_beside_Group.Count - 1);
                            Vector3 temp1 = Vector3.zero;
                            Vector3 temp2 = Vector3.zero;
                            temp1.x = interval * Mathf.Cos(angle2);
                            temp1.z = interval * Mathf.Sin(angle2);
                            temp2.x = interval * Mathf.Cos(angle1);
                            temp2.z = interval * Mathf.Sin(angle1);

                            if (i == leader_position_in_list)
                            {
                                move_target[block_team_beside_Group[i]].x = tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.x;
                                move_target[block_team_beside_Group[i]].z = tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.z;
                                man.offset[0] = Block_beside_Point.x - tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.x;
                                man.offset[2] = Block_beside_Point.z - tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                if (Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]) < block_max_dist_enemy)
                                {
                                    block_beside_arrive = true;
                                }
                            }
                            else
                            {
                                move_target[block_team_beside_Group[i]].x = (leader_position_in_list - i) * temp1.x +
                                    //Mathf.Abs((leader_position_in_list - i)) * temp2.x + 
                                    tankSpawner.Biolist[block_team_beside_leader_num].transform.position.x;
                                move_target[block_team_beside_Group[i]].z = (leader_position_in_list - i) * temp1.z +
                                    //Mathf.Abs((leader_position_in_list - i)) * temp2.z + 
                                    tankSpawner.Biolist[block_team_beside_leader_num].transform.position.z;
                                man.offset[0] = move_target[block_team_beside_Group[i]].x - tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.x;
                                man.offset[2] = move_target[block_team_beside_Group[i]].z - tankSpawner.Biolist[block_team_beside_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                float dist_err = Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]);
                                Vector3 temp = new Vector3(man.transform.forward.x, 0, man.transform.forward.z);
                                temp_angle[block_team_beside_Group[i]] = Vector3.Angle(temp, man.offset);
                                if (temp_angle[block_team_beside_Group[i]] > 90)
                                {
                                    //man.offset[0] = -man.offset[0];
                                    //man.offset[2] = -man.offset[2];
                                    dist_err = -dist_err;
                                }
                                float speed_err = speed[block_team_beside_leader_num] - speed[block_team_beside_Group[i]];
                                float rate = 0.72f;
                                float temp_err = rate * dist_err + (1 - rate) * speed_err;
                                D_error[block_team_beside_Group[i]] = temp_err - P_error[block_team_beside_Group[i]];
                                P_error[block_team_beside_Group[i]] = temp_err;
                                I_error[block_team_beside_Group[i]] += temp_err;

                            }
                            float t = 0.0f;
                            t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));
                            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
                            man.transform.rotation = Quaternion.Lerp(man.transform.rotation, targetRotation, t);
                            float temp_speed = 0;
                            if (i == leader_position_in_list)
                            {
                                temp_speed = 15;
                            }
                            else
                            {
                                temp_speed = PID_Speed(P_error[block_team_beside_Group[i]], I_error[block_team_beside_Group[i]], D_error[block_team_beside_Group[i]], speed[block_team_beside_Group[i]], 0.4f, 0f, 0.4f, 100f);
                                speed[block_team_beside_Group[i]] = temp_speed;
                            }
                            man.move(temp_speed, 0);
                        }

                    }
                }
                else
                {
                    for (int i = 0; i < block_team_beside_Group.Count; i++)
                    {
                        if (tankSpawner.Biolist[block_team_beside_Group[i]].isActiveAndEnabled == true && man.TankNum == block_team_beside_Group[i] + 1)
                        {
                            Scout(man, man.transform);
                        }
                    }
                }
                /////攻中
                ///
                if (!attack_middle_arrive)
                {
                    for (int i = 0; i < attack_team_middle_Group.Count; i++)//剔除死亡
                    {
                        if (tankSpawner.Biolist[attack_team_middle_Group[i]].isActiveAndEnabled == false)
                        {
                            attack_team_middle_Group.RemoveAt(i);
                        }
                    }
                    if (attack_team_middle_Group.Count != 0)
                    {
                        attack_team_middle_leader_num = attack_team_middle_Group[0];
                    }
                    for (int i = 0; i < attack_team_middle_Group.Count; i++)
                    {
                        if (man.TankNum == attack_team_middle_Group[i] + 1)
                        {
                            float angle1 = Mathf.Atan2(tankSpawner.Biolist[attack_team_middle_leader_num].transform.forward.z, tankSpawner.Biolist[attack_team_middle_leader_num].transform.forward.x);
                            float angle2 = angle1 - Mathf.PI / 2;
                            float interval = 10;
                            Vector3 temp1 = Vector3.zero;
                            Vector3 temp2 = Vector3.zero;
                            temp1.x = interval * Mathf.Cos(angle2);
                            temp1.z = interval * Mathf.Sin(angle2);
                            temp2.x = interval * Mathf.Cos(angle1);
                            temp2.z = interval * Mathf.Sin(angle1);

                            if (i == 0)
                            {
                                move_target[attack_team_middle_Group[i]].x = tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.x;
                                move_target[attack_team_middle_Group[i]].z = tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.z;
                                man.offset[0] = Attack_middle_Point.x - tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.x;
                                man.offset[2] = Attack_middle_Point.z - tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                if (Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]) < 100)
                                {
                                    attack_middle_arrive = true;
                                }
                            }
                            else
                            {
                                move_target[attack_team_middle_Group[i]].x = i * temp1.x +
                                    -i * temp2.x +
                                    tankSpawner.Biolist[attack_team_middle_leader_num].transform.position.x;
                                move_target[attack_team_middle_Group[i]].z = i * temp1.z +
                                    -i * temp2.z +
                                    tankSpawner.Biolist[attack_team_middle_leader_num].transform.position.z;
                                man.offset[0] = move_target[attack_team_middle_Group[i]].x - tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.x;
                                man.offset[2] = move_target[attack_team_middle_Group[i]].z - tankSpawner.Biolist[attack_team_middle_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                float dist_err = Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]);
                                Vector3 temp = new Vector3(man.transform.forward.x, 0, man.transform.forward.z);
                                temp_angle[attack_team_middle_Group[i]] = Vector3.Angle(temp, man.offset);
                                if (temp_angle[attack_team_middle_Group[i]] > 90)
                                {
                                    //man.offset[0] = -man.offset[0];
                                    //man.offset[2] = -man.offset[2];
                                    dist_err = -dist_err;
                                }
                                float speed_err = speed[attack_team_middle_leader_num] - speed[attack_team_middle_Group[i]];
                                float rate = 0.72f;
                                float temp_err = rate * dist_err + (1 - rate) * speed_err;
                                D_error[attack_team_middle_Group[i]] = temp_err - P_error[attack_team_middle_Group[i]];
                                P_error[attack_team_middle_Group[i]] = temp_err;
                                I_error[attack_team_middle_Group[i]] += temp_err;

                            }
                            float t = 0.0f;
                            t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));
                            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
                            man.transform.rotation = Quaternion.Lerp(man.transform.rotation, targetRotation, t);
                            float temp_speed = 0;
                            if (i == 0)
                            {
                                temp_speed = 15;
                            }
                            else
                            {
                                temp_speed = PID_Speed(P_error[attack_team_middle_Group[i]], I_error[attack_team_middle_Group[i]], D_error[attack_team_middle_Group[i]], speed[attack_team_middle_Group[i]], 0.4f, 0f, 0.4f, 100f);
                                speed[attack_team_middle_Group[i]] = temp_speed;
                            }
                            man.move(temp_speed, 0);
                        }

                    }
                }
                else
                {
                    for (int i = 0; i < attack_team_middle_Group.Count; i++)
                    {
                        if (tankSpawner.Biolist[attack_team_middle_Group[i]].isActiveAndEnabled == true && man.TankNum == attack_team_middle_Group[i] + 1)
                        {
                            Scout(man, man.transform);
                        }
                    }
                }

                //////////阻中
                ///
                if (!block_middle_arrive)
                {
                    for (int i = 0; i < block_team_middle_Group.Count; i++)//剔除死亡
                    {
                        if (tankSpawner.Biolist[block_team_middle_Group[i]].isActiveAndEnabled == false)
                        {
                            block_team_middle_Group.RemoveAt(i);
                        }
                    }
                    if (block_team_middle_Group.Count != 0)
                    {
                        block_team_middle_leader_num = block_team_middle_Group[0];
                    }
                    for (int i = 0; i < block_team_middle_Group.Count; i++)
                    {
                        if (man.TankNum == block_team_middle_Group[i] + 1)
                        {
                            float angle1 = Mathf.Atan2(tankSpawner.Biolist[block_team_middle_leader_num].transform.forward.z, tankSpawner.Biolist[block_team_middle_leader_num].transform.forward.x);
                            float angle2 = angle1 - Mathf.PI / 2;
                            float interval = 10;
                            Vector3 temp1 = Vector3.zero;
                            Vector3 temp2 = Vector3.zero;
                            temp1.x = interval * Mathf.Cos(angle2);
                            temp1.z = interval * Mathf.Sin(angle2);
                            temp2.x = interval * Mathf.Cos(angle1);
                            temp2.z = interval * Mathf.Sin(angle1);

                            if (i == 0)
                            {
                                move_target[block_team_middle_Group[i]].x = tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.x;
                                move_target[block_team_middle_Group[i]].z = tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.z;
                                man.offset[0] = Block_middle_Point.x - tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.x;
                                man.offset[2] = Block_middle_Point.z - tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                if (Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]) < 100)
                                {
                                    block_middle_arrive = true;
                                }
                            }
                            else
                            {
                                move_target[block_team_middle_Group[i]].x = -i * temp1.x +
                                    -i * temp2.x +
                                    tankSpawner.Biolist[block_team_middle_leader_num].transform.position.x;
                                move_target[block_team_middle_Group[i]].z = -i * temp1.z +
                                    -i * temp2.z +
                                    tankSpawner.Biolist[block_team_middle_leader_num].transform.position.z;
                                man.offset[0] = move_target[block_team_middle_Group[i]].x - tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.x;
                                man.offset[2] = move_target[block_team_middle_Group[i]].z - tankSpawner.Biolist[block_team_middle_Group[i]].transform.position.z;
                                man.offset[1] = 0;//y轴置零
                                float dist_err = Mathf.Sqrt(man.offset[0] * man.offset[0] + man.offset[2] * man.offset[2]);
                                Vector3 temp = new Vector3(man.transform.forward.x, 0, man.transform.forward.z);
                                temp_angle[block_team_middle_Group[i]] = Vector3.Angle(temp, man.offset);
                                if (temp_angle[block_team_middle_Group[i]] > 90)
                                {
                                    //man.offset[0] = -man.offset[0];
                                    //man.offset[2] = -man.offset[2];
                                    dist_err = -dist_err;
                                }
                                float speed_err = speed[block_team_middle_leader_num] - speed[block_team_middle_Group[i]];
                                float rate = 0.72f;
                                float temp_err = rate * dist_err + (1 - rate) * speed_err;
                                D_error[block_team_middle_Group[i]] = temp_err - P_error[block_team_middle_Group[i]];
                                P_error[block_team_middle_Group[i]] = temp_err;
                                I_error[block_team_middle_Group[i]] += temp_err;

                            }
                            float t = 0.0f;
                            t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));
                            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
                            man.transform.rotation = Quaternion.Lerp(man.transform.rotation, targetRotation, t);
                            float temp_speed = 0;
                            if (i == 0)
                            {
                                temp_speed = 15;
                            }
                            else
                            {
                                temp_speed = PID_Speed(P_error[block_team_middle_Group[i]], I_error[block_team_middle_Group[i]], D_error[block_team_middle_Group[i]], speed[block_team_middle_Group[i]], 0.4f, 0f, 0.4f, 100f);
                                speed[block_team_middle_Group[i]] = temp_speed;
                            }
                            man.move(temp_speed, 0);
                        }

                    }
                }
                else
                {
                    for (int i = 0; i < block_team_middle_Group.Count; i++)
                    {
                        if (tankSpawner.Biolist[block_team_middle_Group[i]].isActiveAndEnabled == true && man.TankNum == block_team_middle_Group[i] + 1)
                        {
                            Scout(man, man.transform);

                        }
                    }
                }
            }

        }
        else
        {
            Scout(man, man.transform);
        }

        //赋值到函数外
        Group_1 = Group1;
        Group_2 = Group2;
        //Group_avg_dist_1 = Group_avg_dist1;
        //Group_avg_dist_2 = Group_avg_dist2;
        execute = Execute;

    }

    public void RealShoot(ManControl mancontrol, Vector3 selfPos, Vector3 targetPos)
    {
        float cos35 = Mathf.Cos(35);
        float sin35 = Mathf.Sin(35);
        float Lmaxhigh = (50 * cos35 * 50 * sin35) / 9.81f;
        float Lmax = 2 * Lmaxhigh;
        float dist = (selfPos - targetPos).magnitude;
        float distHorizontal = Mathf.Sqrt(Mathf.Pow((selfPos.x - targetPos.x), 2f) + Mathf.Pow((selfPos.z - targetPos.z), 2f));
        float distVertical = Mathf.Abs(selfPos.y - targetPos.y);

        if (selfPos.y - targetPos.y <= 0)

        {
            if (mancontrol.baseFunction.angleOffset(mancontrol.cannon.eulerAngles.x) - mancontrol.baseFunction.angleOffset(mancontrol.cannon.localRotation.eulerAngles.x) < 10)
            {
                if (distHorizontal <= Lmaxhigh)
                {

                    float result = distHorizontal;
                    //float theta = 0;

                    for (float i = 0; i <= 35; i += 0.1f)
                    {
                        float cosTheta = Mathf.Cos((float)(i * Math.PI / 180f));
                        float sinTheta = Mathf.Sin((float)(i * Math.PI / 180f));

                        float equationResult = (50 * 50 * cosTheta * sinTheta) / 10;

                        if (Math.Abs(equationResult - result) < 0.0001)
                        {
                            mancontrol.theta = i;
                            break;
                        }
                    }
                    //ManControl manControl = new ManControl();
                    mancontrol.OpenFire1(50, (float)mancontrol.theta, 1);
                }


            }
            else
            {
                float Alpha = mancontrol.baseFunction.angleOffset(mancontrol.cannon.eulerAngles.x) + 10;//发炮角度固定为坡度加10，以防打在坡上
                mancontrol.shellspeed = Mathf.Sqrt((float)(9.81f * (targetPos.y - selfPos.y) / (Math.Sin(Alpha) * Math.Sin(Alpha) - Math.Cos(Alpha) * Math.Sin(Alpha))));
                if (mancontrol.shellspeed > 50)
                {
                    mancontrol.shellspeed = 50;
                }
                //ManControl manControl = new ManControl();
                mancontrol.OpenFire1((float)mancontrol.shellspeed, mancontrol.baseFunction.angleOffset(mancontrol.cannon.eulerAngles.x) + 10, 1);
            }

        }
        else
        {
            //float shellspeed;
            float t;
            t = Mathf.Sqrt(2 * distVertical / 9.81f);
            mancontrol.shellspeed = distHorizontal / t;
            //ManControl manControl = new ManControl();
            mancontrol.OpenFire1((float)mancontrol.shellspeed, 0, 1);

        }
    }

    void attack_enemy(ManControl man)
    {
        if (man.MinNum != -1)
        {
            //发炮攻击代码，判定条件：对手距离小于开火距离&&坦克自身炮筒与对手间夹角小于20°&&开火控制位为true
            if (man.EnemyDis[man.MinNum - 1] < man.OpenFireDis && man.Enemyinf[1] < 5.0f && man.ControlFlag == true)
            {
                //RealShoot(man, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position);
                //计算坦克炮筒与对手在XOZ平面的夹角
                man.enemyAngle = baseFunction.DotCalculate3(tankSpawner.BlueAgentsList[man.MinNum - 1].transform, man.transform);
                Vector3 enemyPos = tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position;
                //float[] optimize_result = new float[2];
                man.optimize_result = optimitize_openfire(man, enemyPos, man.shell_start_pos, man.shell_collider_pos, man.enemyAngle1);
                Vector3 vector3 = new Vector3(enemyPos.x, enemyPos.y + 2 + man.optimize_result[1], enemyPos.z) - man.cannon.transform.position;
                //man.enemyAngle = Vector3.Angle(new Vector3(0f, man.cannon.transform.forward.y, 0f), new Vector3(0f, vector3.y, 0f));
                man.enemyAngle = Vector3.Angle(man.cannon.transform.forward, vector3);// + man.setEnemyAngle1;
                //如果setEnemyAngle1 = -1，表示此时角度由计算得出，否则炮筒角度由setEnemyAngle1直接赋值
                //if (man.setEnemyAngle1 == -1) man.enemyAngle1 =
                //        vector3.normalized.y > man.cannon.transform.forward.normalized.y ?
                //        man.enemyAngle : -man.enemyAngle;
                //else man.enemyAngle1 = man.setEnemyAngle1 < 0 ? 0 : man.setEnemyAngle1;
                //man.optimize_result = optimitize_openfire(man, enemyPos, man.shell_start_pos, man.shell_collider_pos, man.enemyAngle1);
                man.enemyAngle1 = vector3.normalized.y > man.cannon.transform.forward.normalized.y ?
                       man.enemyAngle : -man.enemyAngle;
                //man.enemyAngle1 = man.enemyAngle;

                //炮弹速度补偿，根据自身高度调整射速
                if (man.speedControl == true
                    || baseFunction.CalculateDisX0Z(man.transform.position, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position) <= man.BackDistance)
                {
                    float fireSpeedOffset = man.transform.position.y > tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position.y ?
                    man.transform.position.y - tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position.y : 0;
                    fireSpeedOffset = fireSpeedOffset / 30.0f * 2.5f;
                    man.testFireSpeeed = 1 - fireSpeedOffset;
                }
                else
                {
                    if (baseFunction.CalculateDisX0Z(man.transform.position, tankSpawner.BlueAgentsList[man.MinNum - 1].transform.position) > man.BackDistance)
                    {
                        man.testFireSpeeed = 1.0f;
                    }
                }

                man.testFireSpeeed = man.optimize_result[0];
                if (man.SetFireSpeeed != -1)
                {
                    man.testFireSpeeed = man.SetFireSpeeed;
                }

                if (man.EnemyDis[man.MinNum - 1] < 80.0f && man.EnemyDis[man.MinNum - 1] > 10.0f)
                {

                    man.OpenFire2(man.testFireSpeeed, man.enemyAngle1, 1);
                }
                else if (man.EnemyDis[man.MinNum - 1] <= 10.0f)
                    man.OpenFire2(-0.5f, man.enemyAngle1, 1);
            }
        }
    }

    /*
     分情况讨论：
    1、低处打高处，如果短了就角度补偿，长了就速度补偿
    2、高处打低处，即坦克角度为0，速度补偿
     */
    //public float[] result = new float[2];
    public float bio_enemy_dis = 0;
    public float shell_dis = 0;
    float[] optimitize_openfire(ManControl man, Vector3 enemy_pos, Vector3 shell_start, Vector3 shell_end, float enemy_angle)
    {
        float[] result = new float[2];
        if (man.SameFireCount > 10)
        {
            man.BackDistance = 45 - (int)((man.SameFireCount - 10) / 3 + 1) * 5;
        }
        else
            man.BackDistance = 45.0f;
        //float bio_enemy_dis = 0;
        //float shell_dis = 0;
        if (enemy_angle < -1.0f)
        {
            if (man.SameFireCount < 5)
            {
                man.optimize_result[0] = 1 + enemy_angle / 16.0f;
            }
            else
            {
                if (man.left_edge == 1)
                {
                    man.left_edge = -1;
                    man.right_edge = 1;
                    man.optimize_result[0] = 1 + enemy_angle / 16.0f;
                }
                if (Mathf.Abs(man.left_edge - man.right_edge) < 0.01)
                {
                    man.left_edge = -1;
                    man.right_edge = 1;
                    man.optimize_result[0] = 1 + enemy_angle / 16.0f;
                }
                //if(man.firetime < 50)
                //{
                if (man.shell_collider_pos != Vector3.zero)
                {

                    shell_dis = baseFunction.CalculateDisX0Z(shell_start, shell_end);
                }
                else
                {

                    shell_dis = 1000;
                }
                bio_enemy_dis = baseFunction.CalculateDisX0Z(man.transform.position, enemy_pos);


                //if (man.CalFireCount == 0) print("111");
                if (bio_enemy_dis >= shell_dis && man.CalFireCount == 0)
                {
                    //print("112");
                    man.CalFireCount++;
                    man.left_edge = man.optimize_result[0];
                    man.optimize_result[0] = (man.left_edge + man.right_edge) / 2;
                    //right_edge = 
                }
                else if (man.firetime > 50 && man.CalFireCount == 0)
                {
                    man.CalFireCount++;
                    //left_edge = man.fire_speed_buffer;
                    man.right_edge = man.optimize_result[0];
                    man.optimize_result[0] = (man.left_edge + man.right_edge) / 2;
                }
                man.fire_speed_buffer = man.optimize_result[0];

                //}
            }

        }
        else
        {
            man.optimize_result[0] = 1;
        }
        if (enemy_pos.y > man.transform.position.y && Mathf.Abs(enemy_pos.y - man.transform.position.y) > 2)
        {
            if (man.firetime < 80 && shell_end != Vector3.zero)
            {
                bio_enemy_dis = baseFunction.CalculateDisX0Z(man.transform.position, enemy_pos);
                shell_dis = baseFunction.CalculateDisX0Z(shell_start, shell_end);

                if (bio_enemy_dis > shell_dis)//表示对手在山顶，但自己只能打到山坡
                {
                    man.optimize_result[1] = enemy_pos.y - shell_end.y;
                }
            }
            else
            {
                man.optimize_result[1] -= 0.05f;
                if (man.optimize_result[1] <= 0) man.optimize_result[1] = 0;
            }
        }
        else
        {
            man.optimize_result[1] = 2;
        }

        if (man.optimize_result[1] < 0) man.optimize_result[1] = 2;

        return man.optimize_result;
    }

    void behavior_control(ManControl man, Transform transform)
    {
        Vector3 target = new Vector3(0, 0, 0);//这个坐标就是x基准点，需要自己定义
        if (man.TankNum == 0)
        {
            //man.offset = obstacleAvoid.CacPosition(man, transform, target);//求合力，即运行方向
            man.offset = target - transform.position;
            man.offset[1] = 0;//y轴置零
            //t值可以保证坦克在旋转过程中比较平稳
            float t = 0.0f;
            t = Mathf.Clamp01(t + (Time.deltaTime * 3.0f));

            Quaternion targetRotation = Quaternion.LookRotation(man.offset);
            man.transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, t);
            man.move(man.MaxSpeed, 0);//这里速度直接给了最大值，具体使用时需要自己求

        }
    }

}
