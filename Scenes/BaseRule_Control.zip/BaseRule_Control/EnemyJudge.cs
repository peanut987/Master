using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;
using UnityEngine;

public class EnemyJudge : MonoBehaviour
{
	public TankSpawner tankSpawner;
	public TranningSetting trainingSetting;
	public GameManage gameManage;
	private int EnemyNum,TeamNum;
	private int MaxLockNum;
	private Dictionary<int, int> enemyLockCount = new Dictionary<int, int>();//���ڼ��ÿ���Ѵ����˷ֱ𱻶�Ӧ���ٸ��ѷ���������
	public int numberOfTeams = 5;
	public int tanksPerTeam = 4;
	private Dictionary<int, int> teamLeaders = new Dictionary<int, int>();
	public List<Transform> tanks = new List<Transform>();

	void Start()
    {
		trainingSetting = FindObjectOfType<TranningSetting>();
		tankSpawner = FindObjectOfType<TankSpawner>();
		gameManage = FindObjectOfType<GameManage>();
		EnemyNum = trainingSetting.BlueTeam.nums;
		TeamNum = trainingSetting.RedTeam.nums;
		MaxLockNum = 20;
		GetAllTanks();
		//InitializeTeams();
	}

	//�о��ж�
	public void Judge(ManControl man)
	{
        //man.MinNum = findCloseEnemy(man);



        //if (man.LastMinNum == man.ResultMinNum)
        //{
        //������Ķ���
        int index = 0;
        float bufferdis = 10000;
        for (int i = 0; i < EnemyNum; i++)
        {
            if (man.EnemyDis[i] < bufferdis)
            {
                bufferdis = man.EnemyDis[i];
                index = i;
            }
        }
        man.MinNum = index + 1;

		if(trainingSetting.EnvInfo.allview == false)
        {
			if (man.BioEnemydir.Count != 0)// && man.BioEnemydir.Count > 1)
				man.MinNum = findCloseEnemy(man) + 1;
		}
        

        man.MinNumBuffer[1] = man.MinNumBuffer[0];
		man.MinNumBuffer[0] = man.MinNum;
		if (man.MinNumBuffer[0] != man.MinNumBuffer[1])
		{
			man.SameFireCount = 0;
			man.left_edge = -1;
			man.right_edge = 1;
		}
        //if (man.MinNumBuffer[1] == 7 && man.MinNumBuffer[0] == 8) print("11");
		
        //}
        //else if (man.gameManage.enemyCount[man.ResultMinNum - 1] < 3)
        //{
        //	man.gameManage.enemyCount[man.ResultMinNum - 1]++;
        //}
        //else if (man.gameManage.enemyCount[man.MinNum - 1] >= 3)
        //{
        //	man.EnemyDis[man.ResultMinNum - 1] = 10001;
        //}

        //for (int i = 0; i < TeamNum; ++i)
        //{
        //	int teamIndex = tanks[i].GetComponent<ManControl>().GetTeam();
        //	if (teamLeaders.ContainsKey(tankSpawner.Biolist[i].team) && Vector3.Distance(tankSpawner.Biolist[i].transform.position,
        //		tankSpawner.Biolist[teamLeaders[tankSpawner.Biolist[i].team]].transform.position) < 100.0f &&
        //		(tankSpawner.Biolist[i].MinNum != 0 && tankSpawner.Biolist[i].EnemyDis[tankSpawner.Biolist[i].MinNum - 1] < 100.0f))
        //		tankSpawner.Biolist[i].MinNum = tankSpawner.Biolist[teamIndex].MinNum;
        //}

        //enemyLockCount.Clear();

        //for (int i = 0; i < TeamNum; i++)
        //{
        //	LockEnemy(tankSpawner.Biolist[i].MinNum);
        //}

        //man.LastMinNum = man.ResultMinNum;

        //if (man.IsDea) UnlockEnemy(man.MinNum);

        //EnemyChoose(man);

        //if (man.MinNum != 0)
        //Ray_cast(tankSpawner.RLlist[man.MinNum - 1].transform.position);
    }

	int findCloseEnemy(ManControl man, int index = 0)
    {
		int enemyCount = 0;
		//for (int i = 0; i < EnemyNum; i++)
		//{
		//	if (man.EnemyDis[i] < bufferdis)
		//	{
		//		bufferdis = man.EnemyDis[i];
		//		index = i;
		//	}
		//}
		//if (man.BioEnemydir.Count >= index + 1)
		//{
		//	man.ResultMinNum = man.BioEnemydir.ElementAt(index).Value.TankNum;
		//}
		//else
		//	return -1;
		if (man.BioEnemydir.Count < index + 1)
        {
			//(man.TankNum + " : -2");
			return -2;
		}
			
		man.ResultMinNum = man.BioEnemydir.ElementAt(index).Value.TankNum;
		man.BioSameEnemyDir.Clear();
		for (int i = 0; i < TeamNum; i++)
        {
			if(man.ResultMinNum == tankSpawner.Biolist[i].MinNum - 1 && tankSpawner.Biolist[i].isActiveAndEnabled == true)// && i != man.TankNum - 1)
            {
				man.BioSameEnemyDir.TryAdd(tankSpawner.Biolist[i].EnemyDis[man.ResultMinNum], tankSpawner.Biolist[i]);
				//enemyCount++;
            }
        }
		//print(man.TankNum + ": " + man.BioSameEnemyDir.Count);

		for(int i = 0; i < man.BioSameEnemyDir.Count; i++)
        {
			if(man.BioSameEnemyDir.ElementAt(i).Value.TankNum == man.TankNum)
            {
				enemyCount = i;
				break;
			}
        }
		if(enemyCount < 3)
        {
			return man.ResultMinNum;
		}
		else
        {
			//man.EnemyDis[man.ResultMinNum - 1] = 10001;
			return findCloseEnemy(man, index + 1);

		}

	}

	//�жϹ�����������Ķ�����֮�����������Ķ����Ƿ�������������������Ƚ�˫����Ѫ����������������Ķ���Ѫ�����ͣ��򽫸ö���ȷ��Ϊ����Ŀ�ꡣ
	private void EnemyChoose(ManControl man)
	{

		if (man.LastMinNum != man.ResultMinNum && tankSpawner.BlueAgentsList[man.LastMinNum - 1].isActiveAndEnabled == false && man.EnemyDis[man.MinNum - 1] < 30 && Mathf.Min(man.EnemyDis) >= 20)
		{
			if ((man.EnemyDis[man.LastMinNum - 1] > man.OpenFireDis + 5) && (man.EnemyRot[man.ResultMinNum - 1] < 15))
			{
				man.LastMinNum = man.ResultMinNum;
				man.MinNum = man.ResultMinNum;
			}

			if (man.EnemyAttackNum >= 2)
			{
				man.LastMinNum = man.ResultMinNum;
				man.MinNum = man.ResultMinNum;
			}
			if ((tankSpawner.BlueAgentsList[man.LastMinNum - 1].PH - tankSpawner.BlueAgentsList[man.ResultMinNum - 1].PH) > 15)
			{
				man.LastMinNum = man.ResultMinNum;
				man.MinNum = man.ResultMinNum;
			}
			else
				man.MinNum = man.LastMinNum;
		}
		else
		{
			man.MinNum = man.ResultMinNum;
			man.LastMinNum = man.ResultMinNum;
		}
	}

	private bool isBeyondMaxNum(int enemyID)
	{
		if (tankSpawner.BlueAgentsList[enemyID - 1].isActiveAndEnabled && enemyLockCount.ContainsKey(enemyID))
		{
			if (enemyLockCount[enemyID] >= MaxLockNum)
				return true;
		}
		return false;
	}

	//��������Ŀ��
	private void LockEnemy(int enemyID)
	{
		if (enemyLockCount.ContainsKey(enemyID))
		{
			enemyLockCount[enemyID]++;
		}
		else
		{
			enemyLockCount[enemyID] = 1;
		}
	}

	//��������Ŀ��
	private void UnlockEnemy(int enemyID)
	{
		if (enemyLockCount.ContainsKey(enemyID))
		{
			enemyLockCount[enemyID]--;

			if (tankSpawner.BlueAgentsList[enemyID - 1].isActiveAndEnabled == false) //����Ŀ�꽫���ֵ�ȥ��
			{
				enemyLockCount.Remove(enemyID);
			}
		}
	}

	public void GetAllTanks()
	{
		for (int i = 0; i < TeamNum; i++)
		{
			Transform tank = tankSpawner.Biolist[i].transform;
			tanks.Add(tank);
		}
	}

	public void InitializeTeams()
	{
		// ��̹�˷�������鲢���öӳ�
		for (int i = 0; i < numberOfTeams; i++)
		{
			for (int j = 0; j < tanksPerTeam; j++)
			{
				int tankIndex = i * tanksPerTeam + j;
				int teamIndex = i + 1;
				tanks[tankIndex].GetComponent<ManControl>().SetTeam(teamIndex);

				if (j == 0)
				{
					// ��һ��̹����Ϊ�ӳ�
					teamLeaders.Add(teamIndex, tankIndex);
					tankSpawner.Biolist[tankIndex].isLeader = true;
				}
			}
		}
	}

	public void TankDestroyed(int teamIndex)
	{
		// ���ӳ����ݻ�ʱ�����ݶӳ�ְλ�������̹��
		if (teamLeaders.ContainsKey(teamIndex) && tankSpawner.Biolist[teamLeaders[teamIndex]].IsDea == true) 
		{
			float closestDistance = float.MaxValue;
			int newLeaderIndex = -1;
			tankSpawner.Biolist[teamLeaders[teamIndex]].isLeader = false;
			// Ѱ������Ķ���̹��
			for (int i = 0; i < tanks.Count; i++)
			{
				if (tanks[i].GetComponent<ManControl>().GetTeam() == teamIndex && tankSpawner.Biolist[i].IsDea == false)
				{
					float distance = Vector3.Distance(tanks[i].position, tanks[teamLeaders[teamIndex]].position);
					if (distance < closestDistance)
					{
						closestDistance = distance;
						newLeaderIndex = i;
					}
				}
			}

			if (newLeaderIndex != -1)
			{
				// ���ӳ�ְλ���ݸ������̹��
				teamLeaders[teamIndex] = newLeaderIndex;
			}
		}
	}
}
