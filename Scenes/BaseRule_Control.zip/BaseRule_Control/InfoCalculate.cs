using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoCalculate : MonoBehaviour
{
	public TankSpawner tankSpawner;
	private int EnemyNum, TeamNum;
	public TranningSetting trainingSetting;
	public BaseFunction baseFunction;
	// Start is called before the first frame update
	void Start()
	{
		trainingSetting = FindObjectOfType<TranningSetting>();
		baseFunction = FindObjectOfType<BaseFunction>();
		tankSpawner = FindObjectOfType<TankSpawner>();
		EnemyNum = trainingSetting.RedTeam.nums;
		TeamNum = trainingSetting.BlueTeam.nums;
	}

	//���������Ϣ
	public void Calculate(ManControl man, Transform transform)
	{
		//������־�����Ϣ
		man.Enemy_len = man.BioEnemydir.Count;
		for (int i = 0; i < EnemyNum; i++)
		{
            //man.EnemyDis[i] = (tankSpawner.RLlist[i].transform.position - transform.position).magnitude;
            float[] TempRot = baseFunction.DotCalculate2(transform, tankSpawner.BlueAgentsList[i].transform);
			man.EnemyRot[i] = TempRot[1];
            //if (man.EnemyDis[i] > man.ViewDis) 
            //{
            //	man.EnemyDis[i] = 10000;
            //}
            //	if (man.EnemyDis[i] > man.ViewDis)
            //         {
            //	for (int j = 0; j < TeamNum; j++)
            //	{
            //		if (Vector3.Distance(tankSpawner.Biolist[j].transform.position, tankSpawner.RLlist[i].transform.position) <= man.ViewDis)
            //		{
            //			man.EnemyDis[i] = Vector3.Distance(transform.position, tankSpawner.RLlist[i].transform.position);
            //			break;
            //		}
            //	}
            //}
            man.EnemyDis[i] = 10000;
			man.EnemyRot[i] = 10000;
			if (tankSpawner.BlueAgentsList[i].isActiveAndEnabled == true && trainingSetting.EnvInfo.allview == true)
			{
                man.EnemyDis[i] = Vector3.Distance(man.transform.position, tankSpawner.BlueAgentsList[i].transform.position);
                man.EnemyRot[i] = 10000;
            }


			if (trainingSetting.EnvInfo.allview == false)
			{
                if (man.BioEnemydir.Count != 0 && man.EnemyNum >= 20)
                {
                    foreach (var RlTank in man.BioEnemydir)
                    {

                        man.EnemyDis[RlTank.Value.TankNum] = RlTank.Key;
                    }
                }
            }




		}
		//������Ѿ�����Ϣ
		for (int i = 0; i < TeamNum; i++)
		{
			if (i != man.TankNum - 1 && tankSpawner.Biolist[i].isActiveAndEnabled == true)
				man.TeamMateDis1[i] = (tankSpawner.Biolist[i].transform.position - transform.position).magnitude;
			else
				man.TeamMateDis1[i] = 10000.0f;
			//if (man.TankNum == 1) print(i.ToString() + "  :" + man.TeamMateDis1[i]);
		}

		//ͳ�ƴ����Ѿ��͵о���
		man.enemylive = 0;
		man.teammatelive = 0;

		//��������Ѽ�������
		for (int i = 0; i < EnemyNum; i++)
		{
			if (tankSpawner.BlueAgentsList[i].isActiveAndEnabled == true)//&& man.EnemyDis[i] < 60)
				man.enemylive++;

		}
		for (int i = 0; i < TeamNum; i++)
		{
			if (tankSpawner.Biolist[i].isActiveAndEnabled == true)
				man.teammatelive++;
		}

		for (int i = 0; i < TeamNum; i++)
		{
			if (man.EnemyRot[i] < 15 && man.EnemyDis[i] < 40)
				man.EnemyAttackNum++;
		}

		//���¶ӳ�
		for (int i = 0; i < TeamNum; ++i)
		{
			if (man.isLeader && man.IsDea && man.TankNum != 20)
			{
				man.isLeader = false;
				tankSpawner.Biolist[man.TankNum].isLeader = true;
			}
		}
	}
}
